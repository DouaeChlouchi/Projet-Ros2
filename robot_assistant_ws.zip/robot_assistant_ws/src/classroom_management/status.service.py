#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_srvs.srv import Trigger

class RoomStatusService(Node):
    def __init__(self):
        super().__init__('room_status_service')
        self.service = self.create_service(Trigger, 'get_room_status', self.handle_status_request)

    def handle_status_request(self, request, response):
        response.success = True
        response.message = "Salle 101 est libre."
        self.get_logger().info("Demande d'état reçue.")
        return response

def main(args=None):
    rclpy.init(args=args)
    node = RoomStatusService()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()