#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import random

class RoomOccupancyTracker(Node):
    def __init__(self):
        super().__init__('room_occupancy_tracker')
        self.publisher_ = self.create_publisher(String, 'room_occupancy', 10)
        self.timer = self.create_timer(2.0, self.publish_status)

    def publish_status(self):
        status = random.choice(['Libre', 'Occupée'])
        msg = String()
        msg.data = f'Salle 101: {status}'
        self.publisher_.publish(msg)
        self.get_logger().info(f'Statut publié : {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = RoomOccupancyTracker()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()