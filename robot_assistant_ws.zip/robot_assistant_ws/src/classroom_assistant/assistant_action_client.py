#!/usr/bin/env python3
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from example_interfaces.action import Fibonacci

class AssistantActionClient(Node):
    def __init__(self):
        super().__init__('assistant_action_client')
        self.client = ActionClient(self, Fibonacci, 'perform_task')
        self.send_goal(5)

    def send_goal(self, order):
        goal_msg = Fibonacci.Goal()
        goal_msg.order = order
        self.client.wait_for_server()
        self.get_logger().info('Envoi du but...')
        self._send_goal_future = self.client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('But rejeté.')
        return
        self.get_logger().info('But accepté.')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Résultat reçu : {result.sequence}')

def main(args=None):
    rclpy.init(args=args)
    node = AssistantActionClient()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()