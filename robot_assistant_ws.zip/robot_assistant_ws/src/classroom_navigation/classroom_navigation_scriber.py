#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class CoordinatesSubscriber(Node):
    def __init__(self):
        super().__init__('coordinates_subscriber')
        self.subscription = self.create_subscription(
            String, 'room_coordinates', self.process_coordinates, 10)

    def process_coordinates(self, msg):
        self.get_logger().info(f'Reçu les coordonnées: {msg.data}')

def main():
    rclpy.init()
    node = CoordinatesSubscriber()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
