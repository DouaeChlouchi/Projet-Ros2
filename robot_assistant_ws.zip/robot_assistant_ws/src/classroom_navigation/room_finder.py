#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_srvs.srv import Trigger

class RoomFinder(Node):
    def __init__(self):
        super().__init('room_finder')
        self.client = self.create_client(Trigger, 'get_room_status')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('En attente du service...')
        self.request = Trigger.Request()
        self.call_service()

    def call_service(self):
        future = self.client.call_async(self.request)
        future.add_done_callback(self.callback_response)

    def callback_response(self, future):
        response = future.result()
        self.get_logger().info(f'Réponse du service : {response.message}')

    def main(args=None):
        rclpy.init(args=args)
        node = RoomFinder()
        rclpy.spin(node)
        rclpy.shutdown()
    
    if __name__== '__main__':
        main()