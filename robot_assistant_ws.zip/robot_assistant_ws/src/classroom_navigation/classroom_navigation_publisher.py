#!/usr/bin/env python3
import rclpy 
from rclpy.node import Node
from std_msgs.msg import String

class CoordinatesPublisher(Node):
    def __init__(self):
        super().__init__('coordinates_publisher')
        self.publisher_ = self.create_publisher(String, 'room_coordinates', 10)
        self.timer = self.create_timer(2.0, self.publish_coordinates)

    def publish_coordinates(self):
        msg = String()
        msg.data = "Salle 101 : x=2.0, y=3.0"
        self.publisher_.publish(msg)
        self.get_logger().info(f'Coordonnées publiées: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    node = CoordinatesPublisher()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
